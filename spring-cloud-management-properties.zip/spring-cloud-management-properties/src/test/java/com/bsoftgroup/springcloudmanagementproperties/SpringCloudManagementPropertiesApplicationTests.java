package com.bsoftgroup.springcloudmanagementproperties;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudManagementPropertiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
